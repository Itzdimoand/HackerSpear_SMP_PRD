Hacker Spear plugin - शुरुआती source project
लक्षित सर्वर: Paper Minecraft 1.21.11
Java: 21

महत्वपूर्ण:
- यह source project है, पहले से compiled .jar नहीं।
- यह prototype है; abilities/target selection को public server पर इस्तेमाल करने से पहले टेस्ट और balance करें।
- God Spear crafting/combining recipe अभी इस starter version में शामिल नहीं है।

BUILD करने के लिए:
1. PC या cloud IDE में Java JDK 21 और Gradle उपलब्ध रखें।
2. इस folder को खोलें।
3. Terminal में चलाएँ: gradle build
4. सफल होने पर build/libs/HackerSpear-1.0.0.jar (या इसी नाम की jar) बनेगी।
5. उस .jar को Paper server के plugins folder में upload करें।
6. Server restart करें।
7. OP account से command चलाएँ: /hackerspear shadow
   बाकी प्रकार: fire, ice, thunder, poison, wind, earth, light, dark, nature, necro, mystic, god

मोबाइल नोट:
Android पर source edit करना और Gradle build करना कठिन हो सकता है। GitHub Codespaces जैसे cloud development environment या PC का उपयोग करें।
Paper आधिकारिक डाउनलोड: https://papermc.io/downloads
Paper plugin guide: https://docs.papermc.io/paper/dev/
