package me.hackerspear;

import org.bukkit.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

public final class HackerSpearPlugin extends JavaPlugin implements Listener {
    private NamespacedKey spearKey;
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    private final Map<String, String> names = Map.ofEntries(
        Map.entry("shadow", "Shadow Spear"), Map.entry("fire", "Fire Spear"),
        Map.entry("ice", "Ice Spear"), Map.entry("thunder", "Thunder Spear"),
        Map.entry("poison", "Poison Spear"), Map.entry("wind", "Wind Spear"),
        Map.entry("earth", "Earth Spear"), Map.entry("light", "Light Spear"),
        Map.entry("dark", "Dark Spear"), Map.entry("nature", "Nature Spear"),
        Map.entry("necro", "Necro Spear"), Map.entry("mystic", "Mystic Spear"),
        Map.entry("god", "§6§lGOD SPEAR")
    );

    @Override public void onEnable() {
        spearKey = new NamespacedKey(this, "spear_type");
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("HackerSpear enabled.");
    }

    private ItemStack makeSpear(String type) {
        Material material = Material.TRIDENT;
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        String display = names.getOrDefault(type, "Hacker Spear");
        meta.setDisplayName("§b" + display);
        meta.setLore(List.of("§7Right-click to use ability", "§8Hacker Spear SMP"));
        meta.getPersistentDataContainer().set(spearKey, PersistentDataType.STRING, type);
        item.setItemMeta(meta);
        return item;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("This command must be used in-game.");
            return true;
        }
        if (!player.hasPermission("hackerspear.admin")) {
            player.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length != 1 || !names.containsKey(args[0].toLowerCase(Locale.ROOT))) {
            player.sendMessage("§eUse: /hackerspear <shadow|fire|ice|thunder|poison|wind|earth|light|dark|nature|necro|mystic|god>");
            return true;
        }
        String type = args[0].toLowerCase(Locale.ROOT);
        player.getInventory().addItem(makeSpear(type));
        player.sendMessage("§aGiven: " + names.get(type));
        return true;
    }

    @EventHandler public void onUse(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;
        String type = item.getItemMeta().getPersistentDataContainer().get(spearKey, PersistentDataType.STRING);
        if (type == null) return;

        Player p = event.getPlayer();
        long now = System.currentTimeMillis();
        long ready = cooldowns.getOrDefault(p.getUniqueId(), 0L);
        if (now < ready) {
            p.sendMessage("§cAbility cooldown: " + ((ready - now + 999) / 1000) + "s");
            return;
        }
        cooldowns.put(p.getUniqueId(), now + (type.equals("god") ? 12000 : 8000));
        World w = p.getWorld();
        Location loc = p.getLocation();
        Vector direction = p.getLocation().getDirection().normalize();

        switch (type) {
            case "shadow" -> { p.setVelocity(direction.multiply(1.8).setY(0.35)); w.spawnParticle(Particle.SMOKE, loc, 30, .5, .5, .5, .02); }
            case "fire" -> { for (Entity e : p.getNearbyEntities(4, 3, 4)) if (e instanceof LivingEntity le && e != p) { le.damage(5, p); le.setFireTicks(50); } w.spawnParticle(Particle.FLAME, loc, 45, 2, 1, 2, .03); }
            case "ice" -> affectNearby(p, 5, PotionEffectType.SLOWNESS, 80, 1);
            case "thunder" -> { LivingEntity target = target(p, 12); if (target != null) { w.strikeLightningEffect(target.getLocation()); target.damage(7, p); } }
            case "poison" -> affectNearby(p, 4, PotionEffectType.POISON, 100, 0);
            case "wind" -> { for (Entity e : p.getNearbyEntities(5, 3, 5)) if (e instanceof LivingEntity le && e != p) le.setVelocity(le.getLocation().toVector().subtract(loc.toVector()).normalize().multiply(1.2).setY(.5)); p.setVelocity(direction.multiply(1.1).setY(.3)); }
            case "earth" -> affectNearby(p, 3, PotionEffectType.SLOWNESS, 50, 3);
            case "light" -> affectNearby(p, 4, PotionEffectType.BLINDNESS, 50, 0);
            case "dark" -> { LivingEntity target = target(p, 8); if (target != null) { target.damage(5, p); p.setHealth(Math.min(p.getMaxHealth(), p.getHealth() + 3)); } }
            case "nature" -> p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1));
            case "necro" -> { for (int i=0; i<2; i++) { Zombie z = w.spawn(p.getLocation(), Zombie.class); z.setCustomName("§5Necro Minion"); z.setCustomNameVisible(true); z.setTarget(target(p, 12)); z.setRemoveWhenFarAway(true); } p.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 0)); }
            case "mystic" -> { PotionEffectType[] effects = {PotionEffectType.SPEED, PotionEffectType.JUMP_BOOST, PotionEffectType.RESISTANCE, PotionEffectType.STRENGTH}; p.addPotionEffect(new PotionEffect(effects[new Random().nextInt(effects.length)], 160, 1)); }
            case "god" -> { p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 160, 1)); p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 160, 1)); p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 1)); for (Entity e : p.getNearbyEntities(5, 4, 5)) if (e instanceof LivingEntity le && e != p) le.damage(8, p); w.spawnParticle(Particle.END_ROD, loc, 70, 2, 1, 2, .05); }
        }
        p.sendMessage("§a" + names.get(type) + " ability used!");
    }

    private void affectNearby(Player p, double radius, PotionEffectType effect, int ticks, int amplifier) {
        for (Entity e : p.getNearbyEntities(radius, radius, radius))
            if (e instanceof LivingEntity le && e != p) le.addPotionEffect(new PotionEffect(effect, ticks, amplifier));
        p.getWorld().spawnParticle(Particle.SPELL, p.getLocation(), 25, radius/2, 1, radius/2, .05);
    }

    private LivingEntity target(Player p, double range) {
        for (Entity e : p.getNearbyEntities(range, range, range))
            if (e instanceof LivingEntity le && e != p && p.hasLineOfSight(e)) return le;
        return null;
    }
}
